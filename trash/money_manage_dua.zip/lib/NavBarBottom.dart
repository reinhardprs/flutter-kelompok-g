import 'package:flutter/material.dart';
import 'package:money_manage/constants.dart';
import 'home.dart';
import 'manage_data/add_data.dart';
import 'manage_data/edit_maxAmount.dart';
import 'package:flutter_speed_dial/flutter_speed_dial.dart';
import 'package:rive/rive.dart';

class NavbarFinal extends StatefulWidget {
  const NavbarFinal({super.key});

  @override
  State<NavbarFinal> createState() => _NavbarFinalState();
}

class _NavbarFinalState extends State<NavbarFinal> {
  int _selectedIndex = 0;
  final List<Widget> _pages = [
    HomePage(),
    AddData(),
    EditMaxAmount(),
    // Settings(), // Uncomment and create a Settings widget when ready
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          _pages[_selectedIndex],

          Positioned(
            bottom: 15,
            left: 20,
            right: 20,
            child: SafeArea(
              child: ClipRRect(
                borderRadius: BorderRadius.all(Radius.circular(35)),
                child: Container(
                  height: 65,
                  decoration: BoxDecoration(
                    color: kTextColor.withOpacity(0.8),
                    borderRadius: BorderRadius.circular(35),
                    boxShadow: [
                      BoxShadow(
                        color: kPrimaryColor,
                        blurRadius: 4,
                        offset: Offset(4, 8),
                      ),
                    ],
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      IconButton(
                        icon: Icon(Icons.home),
                        color: _selectedIndex == 0 ? kPrimaryColor : kSecondaryColor,
                        onPressed: () => _onItemTapped(0),
                      ),
                      Stack(
                        children: [
                          IconButton(
                            icon: Icon(Icons.add),
                            color: _selectedIndex == 1 ? kPrimaryColor : kSecondaryColor,
                            onPressed: () => _onItemTapped(1),
                          ),
                          Positioned(
                            bottom: 0,
                            left: 0,
                            right: 0,
                            child: SpeedDial(
                              foregroundColor: Colors.white,
                              backgroundColor: kSecondaryColor,
                              child: Icon(Icons.add),
                              childMargin: EdgeInsets.symmetric(vertical: 20, horizontal: 10),
                              children: [
                                SpeedDialChild(
                                  label: "Edit Max Amount",
                                  child: Icon(Icons.edit),
                                  shape: CircleBorder(),
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(builder: (context) => EditMaxAmount()),
                                    );
                                  },
                                ),
                                SpeedDialChild(
                                  label: "Add Expense",
                                  child: Icon(Icons.add),
                                  shape: CircleBorder(),
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(builder: (context) => AddData()),
                                    );
                                  },
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      IconButton(
                        icon: Icon(Icons.settings_outlined),
                        color: _selectedIndex == 2 ? kPrimaryColor : kSecondaryColor,
                        onPressed: () => _onItemTapped(2),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
