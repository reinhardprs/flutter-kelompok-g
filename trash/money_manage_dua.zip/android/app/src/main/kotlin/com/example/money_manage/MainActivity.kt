package com.example.money_manage

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
