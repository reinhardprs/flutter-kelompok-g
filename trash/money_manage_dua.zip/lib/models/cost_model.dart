class CostModel {
  final String? name;
  final double? cost;

  CostModel({this.name, this.cost});
}
